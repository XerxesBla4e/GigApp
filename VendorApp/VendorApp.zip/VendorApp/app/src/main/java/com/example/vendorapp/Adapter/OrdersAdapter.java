package com.example.vendorapp.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vendorapp.Client.OrderDetails;
import com.example.vendorapp.R;
import com.example.vendorapp.Vendor.EditItem;
import com.example.vendorapp.typemodel.ItemModel;
import com.example.vendorapp.typemodel.OrdersModel;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class OrdersAdapter extends FirebaseRecyclerAdapter<OrdersModel, OrdersAdapter.ViewHolder> {
    String imageUri;
    Context context;

    public OrdersAdapter(Context context, FirebaseRecyclerOptions<OrdersModel> options) {
        super(options);
        this.context = context;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ordersrecycler, parent, false);
        return new ViewHolder(view);
    }


    @Override
    protected void onBindViewHolder(ViewHolder viewHolder, int i, OrdersModel ordersModel) {

        //viewHolder.tvstatus.setText(ordersModel.getOrderStatus());
        viewHolder.tvorderid.setText(ordersModel.getOrderID());
        viewHolder.tvtotalcost.setText(ordersModel.getCost());

        String status = ordersModel.getOrderStatus();

        if (status.equals("In Progress")) {
            viewHolder.tvstatus.setText(status);
            viewHolder.tvstatus.setTextColor(context.getResources().getColor(R.color.green_pie));
        } else if (status.equals("Cancelled")) {
            viewHolder.tvstatus.setText(status);
            viewHolder.tvstatus.setTextColor(context.getResources().getColor(R.color.red));
        } else if (status.equals("Confirmed")) {
            viewHolder.tvstatus.setText(status);
            viewHolder.tvstatus.setTextColor(context.getResources().getColor(R.color.light_green));
        }

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, OrderDetails.class);
                intent.putExtra("orderID", ordersModel.getOrderID());
                intent.putExtra("shopID", ordersModel.getOrderTo());
                context.startActivity(intent);
            }
        });
    }


    class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvorderid, tvstatus, tvtotalcost;

        public ViewHolder(View itemView) {
            super(itemView);

            tvorderid = itemView.findViewById(R.id.orderid);
            tvstatus = itemView.findViewById(R.id.status);
            tvtotalcost = itemView.findViewById(R.id.totalcost);
        }

    }

}
