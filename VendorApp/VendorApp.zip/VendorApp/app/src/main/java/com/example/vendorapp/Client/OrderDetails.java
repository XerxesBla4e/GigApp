package com.example.vendorapp.Client;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.vendorapp.Adapter.CartAdapter;
import com.example.vendorapp.Adapter.ItemsAdapter;
import com.example.vendorapp.Adapter.OrdersAdapter;
import com.example.vendorapp.Adapter.ShopAdapter;
import com.example.vendorapp.Constants;
import com.example.vendorapp.Login;
import com.example.vendorapp.R;
import com.example.vendorapp.Vendor.MainVendor;
import com.example.vendorapp.typemodel.DetsModel;
import com.example.vendorapp.typemodel.OrdersModel;
import com.example.vendorapp.typemodel.ShopModel;
import com.example.vendorapp.typemodel.UserDetsModel;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.auth.User;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderDetails extends AppCompatActivity implements View.OnClickListener {
    RecyclerView recyclerView;
    ItemsAdapter itemsAdapter;

    private static final String TAG = "Orders Details";

    private TextView name, OrderId, status, cost;
    String orderID;
    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;
    public String shopID;
    public String telno, name1, id, clientlatitude, clientlongitude, shoplongitude, shoplatitude;
    public int total;
    public int quantity;
    ImageView imgdel, imgedit, phone3, find3;
    public String orderBy;
    List<DetsModel> detsModelList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);

        hooks();

        recyclerView = findViewById(R.id.prods3);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));


        imgedit.setOnClickListener(this);
        imgdel.setOnClickListener(this);
        phone3.setOnClickListener(this);
        find3.setOnClickListener(this);

        firebaseAuth = FirebaseAuth.getInstance();
        /*
        firebaseUser = firebaseAuth.getCurrentUser();
        shopID = firebaseUser.getUid();
*/
        if (getIntent() != null) {
            orderID = getIntent().getStringExtra("orderID");
            shopID = getIntent().getStringExtra("shopID");
        }

        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(shopID).child("Orders");
        databaseReference.child(orderID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                OrdersModel ordersModel = snapshot.getValue(OrdersModel.class);
                if (ordersModel != null) {
                    cost.setText("Total:" + ordersModel.getCost());
                    OrderId.setText(ordersModel.getOrderID());
                    orderBy = ordersModel.getOrderBy();
                    //  clientID = String.valueOf(ordersModel.getOrderBy());
                    status.setText(ordersModel.getOrderStatus());

                    if (status.equals("In Progress")) {
                        status.setText(ordersModel.getOrderStatus());
                        status.setTextColor(getApplicationContext().getResources().getColor(R.color.green_pie));
                    } else if (status.equals("Cancelled")) {
                        status.setText(ordersModel.getOrderStatus());
                        status.setTextColor(getApplicationContext().getResources().getColor(R.color.red));
                    } else if (status.equals("Confirmed")) {
                        status.setText(ordersModel.getOrderStatus());
                        status.setTextColor(getApplicationContext().getResources().getColor(R.color.light_green));
                    }


                    FirebaseDatabase.getInstance().getReference("Users").child(ordersModel.getOrderBy()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot snapshot) {
                            UserDetsModel userDetsModel = snapshot.getValue(UserDetsModel.class);
                            if (userDetsModel != null) {
                                name.setText(userDetsModel.getName());
                                telno = userDetsModel.getPhone();
                                clientlatitude = userDetsModel.getLatitude();
                                clientlongitude = userDetsModel.getLongitude();
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError error) {
                            Toast.makeText(getApplicationContext(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });


                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(shopID).child("Orders");
        databaseReference.child(orderID).child("Items").addValueEventListener(new ValueEventListener() {
           
           /* @Override
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(shopID).child("Orders");
        databaseReference.child(orderID).child("Items").addListenerForSingleValueEvent(new ValueEventListener() {*/
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                DetsModel detsModel = snapshot.getValue(DetsModel.class);

                detsModelList = new ArrayList<>();

                name1 = detsModel.getName();
                id = detsModel.getPid();
                quantity = detsModel.getQuantity();
                total = detsModel.getTotal();

                detsModelList.add(new DetsModel(name1, id, quantity, total));
                itemsAdapter = new

                        ItemsAdapter(detsModelList, getApplicationContext());
                recyclerView.setAdapter(itemsAdapter);
                itemsAdapter.notifyDataSetChanged();
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        FirebaseDatabase.getInstance().getReference("Users").child(shopID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                UserDetsModel userDetsModel = snapshot.getValue(UserDetsModel.class);
                if (userDetsModel != null) {
                    shoplongitude = userDetsModel.getLongitude();
                    shoplatitude = userDetsModel.getLatitude();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Error:" + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void hooks() {
        name = findViewById(R.id.name2);
        OrderId = findViewById(R.id.email2);
        status = findViewById(R.id.status);
        cost = findViewById(R.id.cost);
        imgdel = findViewById(R.id.deleteorder);
        imgedit = findViewById(R.id.editorder);
        phone3 = findViewById(R.id.phone3);
        find3 = findViewById(R.id.find3);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.deleteorder:
                //Toast.makeText(getApplicationContext(), "" + clientID, Toast.LENGTH_SHORT).show();

                FirebaseDatabase.getInstance().getReference("Users").child(shopID).child("Orders")
                        .removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(getApplicationContext(), "Order Record Deleted Successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(OrderDetails.this, MainClient.class));
                        finish();
                    }
                })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                break;
            case R.id.editorder:
                final String[] langs = {"In Progress", "Confirmed", "Cancelled"};
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(OrderDetails.this);
                mBuilder.setTitle("Update Order Status");
                mBuilder.setSingleChoiceItems(langs, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int xer) {
                        if (xer == 0) {
                            HashMap<String, Object> hashMap2 = new HashMap<>();
                            hashMap2.put("orderStatus", "In Progress");
                            String Message = "In Progress";

                            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users");
                            databaseReference.child(shopID).child("Orders").child(orderID).updateChildren(hashMap2);
                            status.setTextColor(getBaseContext().getResources().getColor(R.color.green_pie));

                            preparedNotificationMessage(orderID, Message);
                        } else if (xer == 1) {
                            HashMap<String, Object> hashMap3 = new HashMap<>();
                            hashMap3.put("orderStatus", "Confirmed");
                            String Message = "Confirmed";

                            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users");
                            databaseReference.child(shopID).child("Orders").child(orderID).updateChildren(hashMap3);
                            status.setTextColor(getBaseContext().getResources().getColor(R.color.light_green));

                            preparedNotificationMessage(orderID, Message);
                        } else if (xer == 2) {
                            HashMap<String, Object> hashMap4 = new HashMap<>();
                            hashMap4.put("orderStatus", "Cancelled");
                            String Message = "Cancelled";

                            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users");
                            databaseReference.child(shopID).child("Orders").child(orderID).updateChildren(hashMap4);
                            status.setTextColor(getBaseContext().getResources().getColor(R.color.red));

                            preparedNotificationMessage(orderID, Message);
                        }
                        dialog.dismiss();
                    }
                });
                AlertDialog mDialog = mBuilder.create();
                mBuilder.show();
                break;
            case R.id.phone3:
                makeCall();
                break;
            case R.id.find3:
                locateuser();
                break;
        }
    }

    private void locateuser() {
        String address2 = "https://maps.google.com/maps?saddr" + shoplatitude + "," + shoplongitude + "&saddr=" + clientlatitude + "," + clientlongitude;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(address2));
        startActivity(intent);
    }

    private void makeCall() {
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(telno))));
        Toast.makeText(getApplicationContext(), "" + telno, Toast.LENGTH_SHORT).show();
    }

    private void preparedNotificationMessage(String orderId, String Message) {

        String NOTIFICATION_TOPIC = "/topic/" + Constants.FCM_TOPIC;
        String NOTIFICATION_TITLE = "/Your Order/" + orderId;
        String NOTIFICATION_MESSAGE = "Congratulations...! You have new order";
        String NOTIFICATION_TYPE = "OrderStatusChanged";

        //prepare json what to send and where to send
        JSONObject notificationJo = new JSONObject();
        JSONObject notificationBodyJo = new JSONObject();

        try {
            //what to send
            notificationBodyJo.put("NotificationType", NOTIFICATION_TYPE);
            notificationBodyJo.put("buyerUid", orderBy);
            notificationBodyJo.put("sellerUid", firebaseAuth.getUid());
            notificationBodyJo.put("orderID", orderId);
            notificationBodyJo.put("notificationTitle", NOTIFICATION_TITLE);
            notificationBodyJo.put("notificationMessage", NOTIFICATION_MESSAGE);

            //where to send
            notificationJo.put("to", NOTIFICATION_TOPIC);//all users subscribed to this topic
            notificationJo.put("data", NOTIFICATION_MESSAGE);

        } catch (Exception e) {
            Toast.makeText(this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        sendFcmNotification(notificationJo);
    }

    private void sendFcmNotification(JSONObject notificationJo) {
        //send to volley request
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest("https://fcm.googleapis.com/fcm/send", notificationJo,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                    }
                }, new Response.ErrorListener() {


            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            public Map<String, String> getHeaders() throws AuthFailureError {

                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", "key=" + Constants.FCM_KEY);

                return headers;
            }
        };

        Volley.newRequestQueue(this).add(jsonObjectRequest);
    }
}