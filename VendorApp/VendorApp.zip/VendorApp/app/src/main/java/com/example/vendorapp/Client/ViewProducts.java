package com.example.vendorapp.Client;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.vendorapp.Adapter.ItemAdapter;
import com.example.vendorapp.Adapter.RetrieveAdapter;
import com.example.vendorapp.Constants;
import com.example.vendorapp.R;
import com.example.vendorapp.typemodel.ItemModel;
import com.example.vendorapp.typemodel.ShopModel;
import com.example.vendorapp.typemodel.UserDetsModel;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ViewProducts extends AppCompatActivity implements View.OnClickListener {

    DatabaseReference databaseReference;
    String shopID;
    TextView name, email, fee, opclse;
    ImageView call, find;
    String shopPhone, shoplongitude, shoplatitude, clientlongitude, clientlatitude;
    FirebaseAuth firebaseAuth;
    FirebaseUser user;
    String Id1;

    RecyclerView recyclerView;
    RetrieveAdapter retrieveAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_products);

        hooks();

        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        Id1 = user.getUid();

        call.setOnClickListener(this);
        find.setOnClickListener(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolBar2);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Products");

        if (getIntent() != null) {
            shopID = getIntent().getStringExtra("Shopid");
        }

        databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        databaseReference.child(shopID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                ShopModel shopModel = snapshot.getValue(ShopModel.class);

                if (shopModel != null) {
                    name.setText(shopModel.getName());
                    email.setText(shopModel.getEmail());
                    fee.setText(shopModel.getDeliveryfee());
                    shopPhone = shopModel.getPhone();
                    shoplongitude = shopModel.getLongitude();
                    shoplatitude = shopModel.getLatitude();

                    if (shopModel.getOnline().equals("true")) {
                        opclse.setVisibility(View.INVISIBLE);
                    } else {
                        //opclse.setVisibility(View.VISIBLE);
                        // opclse.setText("open");
                        // opclse.setBackgroundColor(getBaseContext().getResources().getColor(R.color.green_pie));
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FirebaseRecyclerOptions<ItemModel> options =
                new FirebaseRecyclerOptions.Builder<ItemModel>()
                        .setQuery(FirebaseDatabase.getInstance().getReference("Users").child(shopID).child("Products"), ItemModel.class)
                        .build();

        retrieveAdapter = new RetrieveAdapter(getApplicationContext(), options);
        recyclerView.setAdapter(retrieveAdapter);
        retrieveAdapter.notifyDataSetChanged();

        FirebaseDatabase.getInstance().getReference("Users").child(Id1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                UserDetsModel userDetsModel = snapshot.getValue(UserDetsModel.class);
                if (userDetsModel != null) {
                    clientlongitude = userDetsModel.getLongitude();
                    clientlatitude = userDetsModel.getLatitude();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Error:" + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


    private void hooks() {
        name = findViewById(R.id.name1);
        email = findViewById(R.id.email1);
        fee = findViewById(R.id.delfee);
        opclse = findViewById(R.id.openclse);
        recyclerView = findViewById(R.id.prods1);
        call = findViewById(R.id.phone2);
        find = findViewById(R.id.find2);
    }

    @Override
    public void onStart() {
        super.onStart();
        retrieveAdapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        retrieveAdapter.stopListening();
    }

    public boolean onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.search, menu);
        MenuItem item = menu.findItem(R.id.search2);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.phone2:
                dialPhone();
                break;
            case R.id.find2:
                openMap();
                break;
        }
    }

    private void openMap() {
        String address2 = "https://maps.google.com/maps?saddr" + clientlatitude + "," + clientlongitude + "&saddr=" + shoplatitude + "," + shoplongitude;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(address2));
        startActivity(intent);
    }

    private void dialPhone() {
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(shopPhone))));
        Toast.makeText(getApplicationContext(), "" + shopPhone, Toast.LENGTH_SHORT).show();
    }
}