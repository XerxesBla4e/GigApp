package com.example.vendorapp;

public class Constants {
public static final String FCM_KEY = "AAAApwkT1So:APA91bHu7-mdluz2dvUU2UeZgv1R_497RjSkMOGjUlbbbyQloMB1_G8FHeMXHDLp2t9SY2cs9dizfVmBENDZ8M-RhF_agiOdL1Gxk19W6AUccYP679KIp7d5EcKOLORIK3P95VoAEcZs";
public static final String FCM_TOPIC = "PUSH_NOTIFICATIONS";
}
